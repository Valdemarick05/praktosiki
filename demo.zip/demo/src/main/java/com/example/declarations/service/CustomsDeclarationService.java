package com.example.declarations.service;

import com.example.declarations.model.CustomsDeclaration;
import com.example.declarations.repository.CustomsDeclarationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomsDeclarationService {

    @Autowired
    private CustomsDeclarationRepository repository;

    // Создание новой декларации
    public CustomsDeclaration createDeclaration(CustomsDeclaration declaration) {
        return repository.save(declaration);
    }

    // Получение всех деклараций
    public List<CustomsDeclaration> getAllDeclarations() {
        return repository.findAll();
    }

    // Получение декларации по ID
    public Optional<CustomsDeclaration> getDeclarationById(Long id) {
        return repository.findById(id);
    }

    // Поиск декларации по номеру
    public CustomsDeclaration getDeclarationByNumber(String number) {
        return repository.findByDeclarationNumber(number);
    }

    // Фильтрация деклараций по статусу
    public List<CustomsDeclaration> getDeclarationsByStatus(String status) {
        return repository.findByStatus(status);
    }

    // Обновление декларации
    public CustomsDeclaration updateDeclaration(Long id, CustomsDeclaration newDeclaration) {
        return repository.findById(id)
                .map(declaration -> {
                    declaration.setDeclarationNumber(newDeclaration.getDeclarationNumber());
                    declaration.setStatus(newDeclaration.getStatus());
                    declaration.setDescription(newDeclaration.getDescription());
                    return repository.save(declaration);
                })
                .orElse(null);
    }

    // Удаление декларации
    public void deleteDeclaration(Long id) {
        repository.deleteById(id);
    }
}
