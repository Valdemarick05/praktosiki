package com.example.declarations.repository;

import com.example.declarations.model.CustomsDeclaration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomsDeclarationRepository extends JpaRepository<CustomsDeclaration, Long> {
    List<CustomsDeclaration> findByStatus(String status);
    CustomsDeclaration findByDeclarationNumber(String declarationNumber);
}
