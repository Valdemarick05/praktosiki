package com.example.declarations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomsDeclarationApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomsDeclarationApplication.class, args);
    }
}
